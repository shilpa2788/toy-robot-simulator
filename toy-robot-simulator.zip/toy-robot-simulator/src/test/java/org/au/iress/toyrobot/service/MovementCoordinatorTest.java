package org.au.iress.toyrobot.service;

import org.au.iress.toyrobot.constants.RobotOrientation;
import org.au.iress.toyrobot.exception.ToyRoboSimulatorException;
import org.junit.Assert;
import org.junit.Test;

public class MovementCoordinatorTest {

    @Test
    public void moveToyRobotForward() throws ToyRoboSimulatorException {
        PositionAndDirection toyRobotPositionAndDirection = new PositionAndDirection(0, 0, RobotOrientation.NORTH);

        MovementCoordinator moveToyRobot = new MovementCoordinator(toyRobotPositionAndDirection);
        PositionAndDirection positionAndDirection = toyRobotPositionAndDirection.computeAndUpdatePosition();
        Assert.assertTrue(moveToyRobot.moveToyRobotForward(positionAndDirection));
        Assert.assertEquals(0, moveToyRobot.getToyRobotPosition().getX());
        Assert.assertEquals(1, moveToyRobot.getToyRobotPosition().getY());
        Assert.assertEquals(RobotOrientation.NORTH, moveToyRobot.getToyRobotPosition().getDirection());
    }

    @Test
    public void getToyRobotPosition() throws Exception{
        PositionAndDirection toyRobotPositionAndDirection = new PositionAndDirection(0, 0, RobotOrientation.EAST);

        PositionAndDirection positionAndDirection = toyRobotPositionAndDirection.computeAndUpdatePosition();
        Assert.assertEquals(positionAndDirection.getX(), 1);
        Assert.assertEquals(positionAndDirection.getY(), 0);
        Assert.assertEquals(positionAndDirection.getDirection(), RobotOrientation.EAST);

        positionAndDirection = positionAndDirection.computeAndUpdatePosition();
        Assert.assertNotEquals(positionAndDirection.getX(), 1);
        Assert.assertEquals(positionAndDirection.getY(), 0);
        Assert.assertEquals(positionAndDirection.getDirection(), RobotOrientation.EAST);

        positionAndDirection.setDirection(RobotOrientation.NORTH);
        positionAndDirection = positionAndDirection.computeAndUpdatePosition();
        Assert.assertNotEquals(positionAndDirection.getX(), 1);
        Assert.assertEquals(positionAndDirection.getY(), 1);
        Assert.assertNotEquals(positionAndDirection.getDirection(), RobotOrientation.EAST);
    }

    @Test
    public void rotateToyRobotToLeft() {
        RobotOrientation direction = RobotOrientation.EAST;
        direction = direction.rotateLeft(direction);
        Assert.assertEquals(direction, RobotOrientation.NORTH);
        direction = direction.rotateLeft(direction);
        Assert.assertEquals(direction, RobotOrientation.WEST);
        direction = direction.rotateLeft(direction);
        Assert.assertEquals(direction, RobotOrientation.SOUTH);
        direction = direction.rotateLeft(direction);
        Assert.assertEquals(direction, RobotOrientation.EAST);
    }

    @Test
    public void rotateToyRobotToRight() {
        RobotOrientation direction = RobotOrientation.EAST;
        direction = direction.rotateRight(direction);
        Assert.assertEquals(direction, RobotOrientation.SOUTH);
        direction = direction.rotateRight(direction);
        Assert.assertEquals(direction, RobotOrientation.WEST);
        direction = direction.rotateRight(direction);
        Assert.assertEquals(direction, RobotOrientation.NORTH);
        direction = direction.rotateRight(direction);
        Assert.assertEquals(direction, RobotOrientation.EAST);
    }
}