package org.au.iress.toyrobot.service;

import org.au.iress.toyrobot.constants.RobotCommands;
import org.au.iress.toyrobot.constants.RobotOrientation;
import org.au.iress.toyrobot.exception.ToyRoboSimulatorException;
import org.au.iress.toyrobot.factory.impl.TableTopBoundary;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CommandExecutorTest {
    // Update this if width and depth in application.properties is updated
    final int TABLE_WIDTH = 5;
    final int TABLE_DEPTH = 5;
    private TableTopBoundary tableBoundary;
    private MovementCoordinator moveToyRobot;
    private CommandExecutorService commandExecutor;


    @Before
    public void validateInputAndExecute() throws ToyRoboSimulatorException {
        tableBoundary = new TableTopBoundary(TABLE_DEPTH, TABLE_WIDTH);
        moveToyRobot = new MovementCoordinator();
        commandExecutor = new CommandExecutorService(tableBoundary, moveToyRobot);
    }


    @Test
    public void executePlaceCommand() throws ToyRoboSimulatorException {
        Assert.assertTrue(commandExecutor.executePlaceCommand(new PositionAndDirection(0, 1, RobotOrientation.NORTH)));
        Assert.assertFalse(commandExecutor.executePlaceCommand(new PositionAndDirection(6, 6, RobotOrientation.NORTH)));
    }


    @Test
    public void report() throws ToyRoboSimulatorException {
        Assert.assertTrue(commandExecutor.executePlaceCommand(new PositionAndDirection(0, 1, RobotOrientation.NORTH)));
        Assert.assertEquals("Toy Robot's current position is 0,1,NORTH", commandExecutor.executeRobotCommands(RobotCommands.REPORT));
    }

    @Test
    public void placeCommandIssueCheck() throws ToyRoboSimulatorException {
        Assert.assertEquals("Please place the toy robot on the table", commandExecutor.executeRobotCommands(RobotCommands.REPORT));
    }
}