package org.au.iress.toyrobot.factory.impl;

import org.au.iress.toyrobot.service.PositionAndDirection;
import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
public class TableTopBoundaryTest {

    @Test
    public void isRobotOnTheTable() {
        PositionAndDirection mockToyRobotPosition = mock(PositionAndDirection.class);
        when(mockToyRobotPosition.getX()).thenReturn(6);
        when(mockToyRobotPosition.getY()).thenReturn(7);

        TableTopBoundary tableBoundary = new TableTopBoundary(4, 5);
        Assert.assertFalse(tableBoundary.isRobotOnTheTable(mockToyRobotPosition));

        when(mockToyRobotPosition.getX()).thenReturn(1);
        when(mockToyRobotPosition.getY()).thenReturn(1);
        Assert.assertTrue(tableBoundary.isRobotOnTheTable(mockToyRobotPosition));

        when(mockToyRobotPosition.getX()).thenReturn(-1);
        when(mockToyRobotPosition.getY()).thenReturn(-1);
        Assert.assertFalse(tableBoundary.isRobotOnTheTable(mockToyRobotPosition));
    }
}