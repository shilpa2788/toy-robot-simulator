package org.au.iress.toyrobot.service;

import org.au.iress.toyrobot.constants.RobotOrientation;
import org.au.iress.toyrobot.exception.ToyRoboSimulatorException;
import org.au.iress.toyrobot.factory.impl.TableTopBoundary;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class PositionAndDirectionTest {
    private PositionAndDirection positionAndDirection;
    @Before
    public void validateInputAndExecute() throws ToyRoboSimulatorException {
        positionAndDirection = new PositionAndDirection(0, 0, RobotOrientation.EAST);

    }

    @Test
    public void updateToyRobotPosition() {

        positionAndDirection.updateToyRobotPosition(1,1);
        Assert.assertEquals(positionAndDirection.getX(), 1);
        Assert.assertEquals(positionAndDirection.getY(), 1);
        Assert.assertEquals(positionAndDirection.getDirection(), RobotOrientation.EAST);

    }

}