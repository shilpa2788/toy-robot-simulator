package org.au.iress.toyrobot.constants;

import org.junit.Assert;
import org.junit.Test;


public class RobotOrientationTest {


    @Test
    public void rotateLeft() {
        RobotOrientation direction = RobotOrientation.NORTH;
        direction = direction.rotateLeft(direction);
        Assert.assertEquals(direction, RobotOrientation.WEST);
        direction = direction.rotateLeft(direction);
        Assert.assertEquals(direction, RobotOrientation.SOUTH);
        direction = direction.rotateLeft(direction);
        Assert.assertEquals(direction, RobotOrientation.EAST);
        direction = direction.rotateLeft(direction);
        Assert.assertEquals(direction, RobotOrientation.NORTH);
    }

    @Test
    public void rotateRight() {
        RobotOrientation direction = RobotOrientation.SOUTH;
        direction = direction.rotateRight(direction);
        Assert.assertEquals(direction, RobotOrientation.WEST);
        direction = direction.rotateRight(direction);
        Assert.assertEquals(direction, RobotOrientation.NORTH);
        direction = direction.rotateRight(direction);
        Assert.assertEquals(direction, RobotOrientation.EAST);
        direction = direction.rotateRight(direction);
        Assert.assertEquals(direction, RobotOrientation.SOUTH);
    }

}