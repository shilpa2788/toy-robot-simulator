package org.au.iress.toyrobot.constants;


/**
 * ENUM of all valid commands the toy robot can compute
 */
public enum RobotCommands {

    // Place the toy robot for the given X axis and Y axis
    PLACE,

    // Move the toy robot by 1 position in the direction specified
    MOVE,

    // rotate the robot 90 degrees to the left
    LEFT,

    // rotate the robot 90 degrees to the right
    RIGHT,

    // announce the X axis,Y aixs and Facing direction of the toy robot
    REPORT
}