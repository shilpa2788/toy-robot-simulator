package org.au.iress.toyrobot.factory;
import org.au.iress.toyrobot.service.PositionAndDirection;


public interface SquareBoundary
{
    boolean isRobotOnTheTable(PositionAndDirection position);
}
