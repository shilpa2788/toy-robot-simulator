package org.au.iress.toyrobot.exception;

public class ToyRoboSimulatorException extends Exception {

    /**
     * @param errorMessage
     */
    public ToyRoboSimulatorException(String errorMessage) {

        super(errorMessage);
    }
}