package org.au.iress.toyrobot.constants;


import java.util.HashMap;
import java.util.Map;

/**
 * ENUM of the directions which the toy robot takes based on commands
 */
public enum RobotOrientation {


    // Assign 0 for NORTH
    NORTH(0),

    // Assign 1 for EAST
    SOUTH(1),

    // Assign 2 for SOUTH
    EAST(2),

    // Assign 3 for WEST
    WEST(3);

    private final int directionIndex;

    RobotOrientation(int direction) {
        this.directionIndex = direction;
    }


    private static Map<Integer, RobotOrientation> movingDirectionsHashMap = new HashMap<>();


    static {
        for ( RobotOrientation directionEnum : RobotOrientation.values() ) {

            movingDirectionsHashMap.put(directionEnum.directionIndex, directionEnum);
        }
    }


    public static RobotOrientation valueOf(int directionNum) {

        return movingDirectionsHashMap.get(directionNum);
    }

    /**
     * Rotate and return the direction of toy robot facing 90deg to the left
     * FOR NORTH 0: Orientation is WEST 3,
     * FOR SOUTH 1: Orientation.EAST 2,
     * FOR EAST 2: Orientation.NORTH 0,
     * FOR WEST 3 : Orientation.SOUTH 1
     *
     * @param direction
     */
    public RobotOrientation rotateLeft(RobotOrientation direction) {
        int updatedIndex = 0;
        if (direction.directionIndex == 0) {
            updatedIndex = 3;

        } else if (direction.directionIndex == 1) {
            updatedIndex = 2;
        } else if (direction.directionIndex == 2) {
            updatedIndex = 0;
        } else {
            updatedIndex = 1;
        }
        return RobotOrientation.valueOf(updatedIndex);
    }

    /**
     * Rotate and return the direction of toy robot facing 90deg to the right
     * NORTH 0: Rotate to EAST 2,
     * For SOUTH 1: Rotate to WEST 3,
     * For EAST 2: Rotate to SOUTH 1,
     * For WEST 3:  Rotate to NORTH 0
     *
     * @param direction
     */
    public RobotOrientation rotateRight(RobotOrientation direction) {
        int updatedIndex = 0;
        if (direction.directionIndex == 0) {
            updatedIndex = 2;

        } else if (direction.directionIndex == 1) {
            updatedIndex = 3;
        } else if (direction.directionIndex == 2) {
            updatedIndex = 1;
        } else {
            updatedIndex = 0;
        }
        return RobotOrientation.valueOf(updatedIndex);
    }

}