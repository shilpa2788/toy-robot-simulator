package org.au.iress.toyrobot;


import org.au.iress.toyrobot.exception.ToyRoboSimulatorException;
import org.au.iress.toyrobot.factory.impl.TableTopBoundary;
import org.au.iress.toyrobot.service.CommandExecutorService;
import org.au.iress.toyrobot.service.MovementCoordinator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;


/**
 * Entry point to the application
 */
public class ToyRobotSimulatorApplication {


    public static void main(String[] args) throws IOException {
        ToyRobotSimulatorApplication toyRobotSimulator = new ToyRobotSimulatorApplication();
        //Fetch table dimensions and save
        TableTopBoundary tableBoundary = toyRobotSimulator.getTableDimensions();
        MovementCoordinator movementCoordinator = new MovementCoordinator();
        //Simulator is invoked withe table boundary
        CommandExecutorService robotMovementSimulator = new CommandExecutorService(tableBoundary, movementCoordinator);
        BufferedReader userInputReader = new BufferedReader(new InputStreamReader(System.in));
        if (userInputReader == null) {
            System.err.println("No input");
            System.exit(1);
        }
        System.out.println("#####THIS IS A TOY ROBOT SIMULATOR CONSOLE###### ");
        System.out.println("Valid commands for execution are: PLACE X,Y,NORTH | SOUTH | EAST | WEST, MOVE, LEFT, RIGHT, REPORT, STOP");
        System.out.println("Position your toy robot eg: Command PLACE 0,0,NORTH\n");
        boolean isRunning = true;
        while (isRunning) {
            String consoleInput = String.valueOf(userInputReader.readLine());
            //if stop command is issued the console input will not be taken further
            if ("STOP".equalsIgnoreCase(consoleInput)) {
                isRunning = false;
            }
            else {

                try {
                    String result=  robotMovementSimulator.validateInputAndExecute(consoleInput);
                    if (result.equals("true")) {
                        System.out.println("Command received and executed");
                    } else if (result.equals("false")) {

                        System.out.println("Out of table boundary. Command ignored");
                    } else {

                        System.out.println(result);
                    }
                } catch (ToyRoboSimulatorException toyRobotException) {

                    System.out.println(toyRobotException.getMessage());
                }
            }
        }
    }

    /**
     * Method to return table boundary defined in the properties
     *
     * @return
     * @throws IOException
     */
    public TableTopBoundary getTableDimensions() throws IOException {

        InputStream inputStream = ToyRobotSimulatorApplication.class.getClassLoader().getResourceAsStream("application.properties");
        Properties properties = new Properties();

        if (inputStream == null) {

            System.out.println("Sorry, unable to find application.properties file");
        }

        properties.load(inputStream);
        String tableWidth = properties.getProperty("table.width");
        String tableDepth = properties.getProperty("table.depth");

        TableTopBoundary tableBoundary = new TableTopBoundary(Integer.valueOf(tableWidth), Integer.valueOf(tableDepth));

        return tableBoundary;
    }
}

