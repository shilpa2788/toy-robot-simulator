package org.au.iress.toyrobot.factory.impl;

import org.au.iress.toyrobot.factory.SquareBoundary;
import org.au.iress.toyrobot.service.PositionAndDirection;

/**
 * Class to set the table boundaries
 */
public class TableTopBoundary implements SquareBoundary {

    int width;
    int depth;

    public TableTopBoundary(int width, int depth) {
        this.width = width;
        this.depth = depth;
    }

    /**
     * Overridden interface method to validate whether the toy robot is within the boundary of the table
     * @param position
     * @return
     */
    public boolean isRobotOnTheTable(PositionAndDirection position) {

        return !(position.getX() >= this.depth ||
                position.getX() < 0 ||
                position.getY() >= this.width ||
                position.getY() < 0
        );
    }
}
