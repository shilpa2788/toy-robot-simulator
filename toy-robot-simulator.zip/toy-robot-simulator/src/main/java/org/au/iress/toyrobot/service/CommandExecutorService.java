package org.au.iress.toyrobot.service;

import org.au.iress.toyrobot.constants.RobotCommands;
import org.au.iress.toyrobot.constants.RobotOrientation;
import org.au.iress.toyrobot.exception.ToyRoboSimulatorException;
import org.au.iress.toyrobot.factory.SquareBoundary;

public class CommandExecutorService {

    SquareBoundary tableBoundary;
    RobotCommands command;
    MovementCoordinator movementCoordinator;
    private int x;
    private int y;
    private RobotOrientation commandDirection;

    public CommandExecutorService(SquareBoundary tableBoundary, MovementCoordinator movementCoordinator) {

        this.tableBoundary = tableBoundary;
        this.movementCoordinator = movementCoordinator;

    }

    /**
     * Validate the input arguments
     *
     * @param inputString
     * @throws ToyRoboSimulatorException
     */
    public String validateInputAndExecute(String inputString) throws ToyRoboSimulatorException {
        String result = "false";
        String[] args = inputString.split(" ");
        //Validating the input command
        try {

            command = command.valueOf(args[0]);
        } catch (Exception exception) {

            throw new ToyRoboSimulatorException("Unrecognised/Invalid command");
        }
        if (command == RobotCommands.PLACE && args.length < 2) {

            throw new ToyRoboSimulatorException("Invalid/Incomplete command");
        }

        //Check for PLACE command
        String[] params;

        if (command == RobotCommands.PLACE) {
            params = args[1].split(",");
            try {
                this.x = Integer.parseInt(params[0]);
                this.y = Integer.parseInt(params[1]);
                this.commandDirection = RobotOrientation.valueOf(params[2]);

            } catch (Exception exception) {
                throw new ToyRoboSimulatorException("Invalid/Incomplete command");
            }
        }

        result= executeRobotCommands(command);
        return result;
    }

    /**
     * @param command
     * @throws ToyRoboSimulatorException
     */
    public String executeRobotCommands(RobotCommands command) throws ToyRoboSimulatorException {
       String result = "false";
        try {
            switch (command) {
                case PLACE:
                    // place robot in that position
                    result =  String.valueOf(executePlaceCommand(new PositionAndDirection(x, y, commandDirection)));
                    break;

                case MOVE:
                    PositionAndDirection positionAndDirection = movementCoordinator.getToyRobotPosition().computeAndUpdatePosition();
                    if (tableBoundary.isRobotOnTheTable(positionAndDirection)) {
                        result=  String.valueOf(movementCoordinator.moveToyRobotForward(positionAndDirection));
                    }
                    break;

                case LEFT:
                    result=  String.valueOf(movementCoordinator.rotateToyRobotToLeft());
                    break;

                case RIGHT:
                    result =  String.valueOf(movementCoordinator.rotateToyRobotToRight());
                    break;

                case REPORT:
                    result =   String.valueOf(report());
                    break;

                default:
                    throw new ToyRoboSimulatorException("Unrecognised command");
            }
        } catch (Exception exception) {
            throw new ToyRoboSimulatorException("Please place the toy robot on the table issuing PLACE Command");
        }
        return result;
    }

    /**
     * Determine the position of the toy robot on the table at X,Y and facing in the direction NORTH | SOUTH | EAST | WEST
     *
     * @param toyRobotPositionAndDirection Robot position
     * @return true if placed successfully
     * @throws ToyRoboSimulatorException
     */
    public boolean executePlaceCommand(PositionAndDirection toyRobotPositionAndDirection) throws ToyRoboSimulatorException {


        //Validate the boundary given is empty or null
        if (tableBoundary == null) {

            throw new ToyRoboSimulatorException("Out of table boundary. Command ignored");
        }
        //Validate the toyRobotPositionAndDirection
        if (toyRobotPositionAndDirection == null) {

            throw new ToyRoboSimulatorException("Invalid position");
        }

        if (toyRobotPositionAndDirection.getDirection() == null) {

            throw new ToyRoboSimulatorException("Invalid direction");
        }

        if (!tableBoundary.isRobotOnTheTable(toyRobotPositionAndDirection)) {

            return false;
        }

        movementCoordinator.isToyRobotSetPosition(toyRobotPositionAndDirection);

        return true;
    }


    /**
     * Method to return the current position of the toy robot in X,Y,DIRECTION format
     */
    public String report() {
        if (movementCoordinator.getToyRobotPosition() == null) {

            return "Please place the toy robot on the table";

        }

        return "Toy Robot's current position is "
                + movementCoordinator.getToyRobotPosition().getX() + ","
                + movementCoordinator.getToyRobotPosition().getY() + ","
                + movementCoordinator.getToyRobotPosition().getDirection();
    }
}
