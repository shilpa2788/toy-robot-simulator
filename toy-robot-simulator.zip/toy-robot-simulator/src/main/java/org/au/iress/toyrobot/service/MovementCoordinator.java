package org.au.iress.toyrobot.service;

import org.au.iress.toyrobot.exception.ToyRoboSimulatorException;

public class MovementCoordinator {

    private PositionAndDirection toyRobotPosition;

    /**
     * Empty constructor for unit tests
     */
    public MovementCoordinator() {

    }

    public MovementCoordinator(PositionAndDirection positionAndDirection) {
    }

    public boolean isToyRobotSetPosition(PositionAndDirection toyRobotPosition) {

        if (toyRobotPosition == null) {

            return false;
        }
        this.toyRobotPosition = toyRobotPosition;

        return true;
    }

    /**
     * Moves the robot one unit forward in the direction it is currently facing
     *
     * @return true if moved successfully
     */
    public boolean moveToyRobotForward(PositionAndDirection newToyRobotPosition) {

        if (newToyRobotPosition == null) {

            return false;
        }

        this.toyRobotPosition = newToyRobotPosition;

        return true;
    }

    public PositionAndDirection getToyRobotPosition() {

        return this.toyRobotPosition;
    }

    /**
     * Rotates the robot 90 degrees LEFT
     *
     * @return true if rotated successfully
     */
    public boolean rotateToyRobotToLeft() {
        if (this.toyRobotPosition.getDirection() == null) {

            return false;
        }

        this.toyRobotPosition.setDirection(this.toyRobotPosition.getDirection()
                .rotateLeft(this.toyRobotPosition.getDirection()));
        return true;
    }

    /**
     * Rotates the robot 90 degrees RIGHT
     * @return true if rotated successfully
     */
    public boolean rotateToyRobotToRight() {

        if (this.toyRobotPosition.getDirection() == null) {

            return false;
        }
        this.toyRobotPosition.setDirection(this.toyRobotPosition.getDirection()
                .rotateRight(this.toyRobotPosition.getDirection()));

        return true;
    }
}