package org.au.iress.toyrobot.service;


import org.au.iress.toyrobot.constants.RobotOrientation;
import org.au.iress.toyrobot.exception.ToyRoboSimulatorException;

/**
 * Class to set the position and direction of the toy robot
 */
public class PositionAndDirection {

    int x;
    int y;
    RobotOrientation direction;

    /**
     * Constructor to store the orientation and direction of the toy robot
     * @param orientation
     */
    public PositionAndDirection(PositionAndDirection orientation) {

        this.x = orientation.getX();
        this.y = orientation.getY();
        this.direction = orientation.getDirection();
    }

    /**
     * for unit tests
     * @param x
     * @param y
     * @param direction
     */
    public PositionAndDirection(int x, int y, RobotOrientation direction) {

        this.x = x;
        this.y = y;
        this.direction = direction;
    }


    public int getX() {

        return this.x;
    }

    public int getY() {

        return this.y;
    }

    public RobotOrientation getDirection() {

        return this.direction;
    }

    public void setDirection(RobotOrientation direction) {

        this.direction = direction;
    }

    /**
     * update the new position of the toy robot computed upon user commands
     * @param x
     * @param y
     */
    public void updateToyRobotPosition(int x, int y) {

        this.x = this.x + x;
        this.y = this.y + y;
    }

    /**
     * compute toy robots current coordinates of the toy robot based on user input
     * @return
     * @throws ToyRoboSimulatorException
     */
    public PositionAndDirection computeAndUpdatePosition() throws ToyRoboSimulatorException {

        if (this.direction == null) {

            throw new ToyRoboSimulatorException("Invalid robot direction");
        }

        PositionAndDirection updatePosition = new PositionAndDirection(this);

        switch (this.direction) {

            case NORTH:
                updatePosition.updateToyRobotPosition(0, 1);
                break;

            case EAST:
                updatePosition.updateToyRobotPosition(1, 0);
                break;

            case SOUTH:
                updatePosition.updateToyRobotPosition(0, -1);
                break;

            case WEST:
                updatePosition.updateToyRobotPosition(-1, 0);
                break;
        }

        return updatePosition;
    }
}